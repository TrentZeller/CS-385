/*******************************************************************************
 * Name        : waterjugpuzzle.cpp
 * Author      : Trent Zeller
 * Date        : October 16, 2020
 * Description : Solution to the waterjug problem.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <iostream>
#include <sstream>
#include <queue>
#include <vector>

using namespace std;

//state struct you outlined for us
struct State{
	int a, b, c;
	string directions;
	State *parent;

	State() : a{0}, b{0}, c{0}, directions{""}, parent{nullptr} {}

	State(int _a, int _b, int _c, string _directions) :
		a{_a}, b{_b}, c{_c}, parent{nullptr} {
			directions.assign(_directions);
	}

	string to_string(){
		ostringstream oss;
		oss << "(" << a << ", " << b << ", " << c << ")";
		return oss.str();
	}
};

//checks if the values of two states are equal
bool equals(State a, State b){
	return (a.a == b.a && a.b == b.b && a.c == b.c);
}

//function to return the steps to solve the problem
string print_return_string(State last){
	State current = last;
	string rtrn;

	//loops through all parent pointers
	while(current.parent != nullptr){
		rtrn = current.directions + " " + current.to_string() + "\n" + rtrn;
		current = *current.parent;
	}

	rtrn = current.directions + " " + current.to_string() + "\n" + rtrn;
	return rtrn;
}

string bfs(int a, int b, int c, string directions, vector<vector<State>> &visited, int values[]){
	queue<State> graph;
	graph.push(State(a,b,c,directions));
	State empty(0,0,0,"");

	while(!graph.empty()){
		State current = graph.front();
		graph.pop();

		if(equals(State(values[3], values[4], values[5], ""), current)){
			return print_return_string(current);
		}

		if(equals(visited[current.a][current.b], empty)){
			visited[current.a][current.b] = current;

			//C -> A
			if(current.a <= values[0] && current.c >= 0){
				int temp = values[0]-current.a;
				int temp_a = current.a, temp_b = current.b, temp_c = current.c;
				if(temp > current.c){
					temp = current.c;
				}
				ostringstream oss;
				if(temp > 1){
					oss << "Pour " << temp << " gallons from C to A.";
				}
				else{
					oss << "Pour " << temp << " gallon from C to A.";
				}
				State next(temp_a += temp, temp_b, temp_c -= temp, oss.str());
				next.parent = &visited[current.a][current.b];
				graph.push(next);
			}

			//B -> A
			if(current.a <= values[0] && current.b > 0){
				int temp = values[0]-current.a;
				int temp_a = current.a, temp_b = current.b, temp_c = current.c;
				if(temp > current.b){
					temp = current.b;
				}
				ostringstream oss;
				if(temp > 1){
					oss << "Pour " << temp << " gallons from B to A.";
				}
				else{
					oss << "Pour " << temp << " gallon from B to A.";
				}
				State next(temp_a += temp, temp_b -= temp, temp_c, oss.str());
				next.parent = &visited[current.a][current.b];
				graph.push(next);
			}

			//C -> B
			if(current.b <= values[1] && current.c >= 0){
				int temp = values[1]-current.b;
				int temp_a = current.a, temp_b = current.b, temp_c = current.c;
				if(temp > current.c){
					temp = current.c;
				}
				ostringstream oss;
				if(temp > 1){
					oss << "Pour " << temp << " gallons from C to B.";
				}
				else{
					oss << "Pour " << temp << " gallon from C to B.";
				}
				State next(temp_a, temp_b += temp, temp_c -= temp, oss.str());
				next.parent = &visited[current.a][current.b];
				graph.push(next);
			}

			//A -> B
			if(current.b <= values[1] && current.a >= 0){
				int temp = values[1]-current.b;
				int temp_a = current.a, temp_b = current.b, temp_c = current.c;
				if(temp > current.a){
					temp = current.a;
				}
				ostringstream oss;
				if(temp > 1){
					oss << "Pour " << temp << " gallons from A to B.";
				}
				else{
					oss << "Pour " << temp << " gallon from A to B.";
				}
				State next(temp_a -= temp, temp_b += temp, temp_c, oss.str());
				next.parent = &visited[current.a][current.b];
				graph.push(next);
			}

			//B -> C
			if(current.c <= values[2] && current.b >= 0){
				int temp = values[2]-current.c;
				int temp_a = current.a, temp_b = current.b, temp_c = current.c;
				if(temp > current.b){
					temp = current.b;
				}
				ostringstream oss;
				if(temp > 1){
					oss << "Pour " << temp << " gallons from B to C.";
				}
				else{
					oss << "Pour " << temp << " gallon from B to C.";
				}
				State next(temp_a, temp_b -= temp, temp_c += temp, oss.str());
				next.parent = &visited[current.a][current.b];
				graph.push(next);
			}

			//A -> C
			if(current.c <= values[2] && current.a >= 0){
				int temp = values[2]-current.c;
				int temp_a = current.a, temp_b = current.b, temp_c = current.c;
				if(temp > current.a){
					temp = current.a;
				}
				ostringstream oss;
				if(temp > 1){
					oss << "Pour " << temp << " gallons from A to C.";
				}
				else{
					oss << "Pour " << temp << " gallon from A to C.";
				}
				State next(temp_a -= temp, temp_b, temp_c += temp, oss.str());
				next.parent = &visited[current.a][current.b];
				graph.push(next);
			}
		}
	}
	return "No solution.";
}

//checks to make sure arguments are correct
bool check_args(int argc, char * const argv[]){
	istringstream iss;

	for(int i = 1; i < argc; i++){
		int m;

		iss.str(argv[i]);
		if( !(iss >> m) || m < 0 || (m ==0 && i == 3)){
			string jugs[] = {"A", "B", "C"};

			if(i <= argc/2){
				cerr << "Error: Invalid capacity '" << iss.str() << "' for jug " << jugs[i - 1] << ".";
				return 1;
			}
			else{
				cerr << "Error: Invalid goal '" << iss.str() << "' for jug " << jugs[i - 4] << ".";
				return 1;
			}
		}
		iss.clear();
	}

	return 0;
}

//checks to make sure goals are allowed
bool check_goals(int values[], int size){
	string jugs[] = {"A", "B", "C"};

	for(int i = 0; i < size / 2; i++){
		if (values[i + 3] > values[i]){
			cerr << "Error: Goal cannot exceed capacity of jug " << jugs[i] << ".";
			return 1;
		}
	}

	//can hardcode because locations are always the same
	if((values[3] + values[4] + values[5]) != values[2]){
		cerr << "Error: Total gallons in goal state must be equal to the capacity of jug C.";
		return 1;
	}
	return 0;
}

int main(int argc, char * const argv[]){
	istringstream iss;
	int values[6];
	State empty(0,0,0,"");

	if(argc != 7){
		cerr << "Usage: " << argv[0] << " <cap A> <cap B> <cap C> <goal A> <goal B> <goal C>" << endl;
		return 1;
	}

	if(check_args(argc, argv)){
		return 1;
	}

	//creates list of the arguments
	for(int i = 1; i <= argc - 1; i++){
		int m;
		iss.str(argv[i]);
		iss >> m;
		values[i - 1] = m;
		iss.clear();
	}

	//can hardcode size because number of arguments will always be the same.
	if(check_goals(values, 6)){
		return 1;
	}

	vector<vector<State>> visited( values[0] + 1, vector<State> (values[1] + 1));

	for(unsigned int i = 0; i < visited.size(); ++i){
		visited[i].push_back(empty);
	}

	string str = bfs(0,0,values[2], "Initial state.", visited, values);
	cout << str;

	return 0;
}
