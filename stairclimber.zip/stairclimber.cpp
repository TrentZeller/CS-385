/*******************************************************************************
 * Name        : stairclimber.cpp
 * Author      : Trent Zeller
 * Date        : September 26, 2020
 * Description : Lists the number of ways to climb n stairs.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <iomanip>

using namespace std;

vector< vector<int> > get_ways(int num_stairs) {
    vector<vector<int>> ways = {};

    //base case
    if(num_stairs <= 0){
    	ways.push_back({});
    }
    else{
    	//number of steps you can take at once
    	for(int i = 1; i <= 3; i++){

    		//recursively finds remaining stairs needed after taking step
    		if(num_stairs >= i){
    			vector<vector<int>> result = get_ways(num_stairs - i);

    			//adds current step to vector
    			for(unsigned int j = 0; j < result.size(); ++j){
    				result.at(j).insert(result.at(j).begin(), i);
    			}
    			//adds result onto end of ways
    			ways.insert(ways.end(), result.begin(), result.end());
    		}
    	}
    }

    return ways;
}

//find the width of a number
int num_width(int num){
	int width = 1;

	while (num >= 10){
		num = num / 10;
		width++;
	}
	return width;
}
//returns the number of spaces needed to right align the numbers with the largest number
int num_spaces(int last, int curr){
	int largest = num_width(last);
	int current = num_width(curr);

	return largest - current;
}

void display_ways(const vector< vector<int> > &ways) {
	int spaces;

	for (unsigned int x = 0; x < ways.size(); ++x){
		spaces = num_spaces(ways.size() - 1, x + 1);
		while(spaces > 0){
			cout << " ";
			spaces--;
		}
		cout << x+1 << ". " << "[";
		for(unsigned int i = 0; i < ways[x].size(); ++i){
			if(i + 1 < ways[x].size()){
				cout << ways[x][i] << ", ";
			}
			else{
				cout << ways[x][i];
			}
		}
		cout << "]" << endl;
	}
}

int main(int argc, char * const argv[]) {
	int m;
	istringstream iss;

	//check arguments
	if(argc != 2){
		cerr << "Usage: " << argv[0] << " <number of stairs>" << endl;
		return 1;
	}

	iss.str(argv[1]);
	if ( !(iss >> m)) {
		cerr << "Error: Number of stairs must be a positive integer." << endl;
		return 1;
	}

	if(m <= 0 ){
		cerr << "Error: Number of stairs must be a positive integer." << endl;
		return 1;
	}

	iss.clear();
	vector< vector<int>> ways = get_ways(m);

	//print ways
	if(ways.size() == 1){
		cout << "1 way to climb 1 stair." << endl;;
	}
	else{
		cout << ways.size() << " ways to climb " << m << " stairs." << endl;
	}

	display_ways(ways);

	return 0;

}
