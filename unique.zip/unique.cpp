/*******************************************************************************
 * Name        : unique.cpp
 * Author      : Trent Zeller
 * Date        : September 23, 2020
 * Description : Determining uniqueness of chars with int as bit vector.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <iostream>
#include <cctype>
#include <sstream>

using namespace std;

bool is_all_lowercase(const string &s) {
	int length = s.length();

	//uses ascii values to make sure strings are lowercase
    for (int i = 0; i < length; i++){
    	if(s.at(i) <= 93 || s.at(i) >= 123){
    		return false;
    	}
    }
    return true;
}

bool all_unique_letters(const string &s) {
    unsigned int vector = 0, setter = 1;
    int length = s.length();

    //follows algorithm outlined in lecture
    for (int i = 0; i < length; i++){
    	//shift setter to work with bit corresponding to each letter
    	setter = setter << (s.at(i) - 'a');
        if((setter & vector) != 0){
       		return false;
       	}
       	else{
       		//update vector and reset setter each time
       		vector = setter | vector;
       		setter = 1;
       	}
     }
    return true;
}

int main(int argc, char * const argv[]) {
		string s;
		istringstream iss;

		if(argc != 2){
			cerr << "Usage: " << argv[0] << " <string>" << endl;
			return 1;
		}

		iss.str(argv[1]);
		if ( !(iss >> s) || !is_all_lowercase(s)) {
			cerr << "Error: String must contain only lowercase letters." << endl;
			return 1;
		}

		iss.clear();

		if(all_unique_letters(s)){
			cout << "All letters are unique." << endl;
		}
		else{
			cout << "Duplicate letters found." << endl;
		}

		return 0;
}
