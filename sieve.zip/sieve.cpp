/*******************************************************************************
 * Name        : sieve.cpp
 * Author      : Trent Zeller
 * Date        : September 15, 2020
 * Description : Sieve of Eratosthenes
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <cmath>
#include <iomanip>
#include <iostream>
#include <sstream>

using namespace std;

class PrimesSieve {
public:
    PrimesSieve(int limit);

    ~PrimesSieve() {
        delete [] is_prime_;
    }

    int num_primes() const {
        return num_primes_;
    }

    void display_primes() const;

private:
    // Instance variables
    bool * const is_prime_;
    const int limit_;
    int num_primes_, max_prime_;

    // Method declarations
    int count_num_primes() const;
    void sieve();
    static int num_digits(int num);
};

PrimesSieve::PrimesSieve(int limit) :
        is_prime_{new bool[limit + 1]}, limit_{limit} {
    sieve();
}

void PrimesSieve::display_primes() const {
	//code we were given to find length of primes/primes in a row
	const int max_prime_width = num_digits(max_prime_);
	const int primes_per_row = 80 / (max_prime_width + 1);

	//if number of primes is less than the max in one row just prints them with a space
	if(num_primes_ <= primes_per_row){
		cout << 2;
		for (int x = 3; x <= limit_; x++){
			if(!is_prime_[x]){
				cout << " " << x;
			}
		}
	}
	else{
		int start = num_digits(max_prime_) - 1;
		int count = 1;

		cout << setw(start + 1) << 2;

		for (int x = 3; x <= limit_; x++){
			if(!is_prime_[x]){
				//uses a count to check if there's more primes than should be in a single row
				if(count >= primes_per_row){
					count = 1;
					start = max_prime_width - num_digits(is_prime_[x]);

					//starts new row
					cout << endl << setw(max_prime_width - num_digits(is_prime_[x]) + 1) << x;
				}
				else{
					cout  << " " << setw(max_prime_width - num_digits(is_prime_[x]) + 1) << x;
					count ++;
				}
			}
		}
	}
}

int PrimesSieve::count_num_primes() const {
    int count = 0;

	for (int x = 2; x <= limit_; x++){
    	if( !is_prime_[x] ){
    		count++;
    	}
    }
	return count;
}

void PrimesSieve::sieve() {
	//follows sieve algorithm to make all primes with false
    for (int x = 2; x <= sqrt(limit_); x++){
    	if(!is_prime_[x]){
    		for (int i = x * x; i <= limit_; i += x){
    			is_prime_[i] = true;
    		}
    	}
    }
    num_primes_ = count_num_primes();

    //finds last prime
    int i = limit_;
    while (is_prime_[i] != 0){
    	i--;
    }
    max_prime_ = i;
}

int PrimesSieve::num_digits(int num) {
    int count = 1;

    //divides by 10 to count the number of digits
	while (num > 10){
    	num = num / 10;
    	count++;
    }

    return count;
}

int main() {
    cout << "**************************** " <<  "Sieve of Eratosthenes" <<
            " ****************************" << endl;
    cout << "Search for primes up to: ";
    string limit_str;
    cin >> limit_str;
    int limit;

    // Use stringstream for conversion. Don't forget to #include <sstream>
    istringstream iss(limit_str);

    // Check for error.
    if ( !(iss >> limit) ) {
        cerr << "Error: Input is not an integer." << endl;
        return 1;
    }
    if (limit < 2) {
        cerr << "Error: Input must be an integer >= 2." << endl;
        return 1;
    }
    //displays number of primes
    PrimesSieve sieve1(limit);
    cout << endl << "Number of primes found: " << sieve1.num_primes() << endl;
    cout << "Primes up to " << limit << ":" << endl;
    sieve1.display_primes();

    return 0;
}
