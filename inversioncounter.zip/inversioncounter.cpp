/*******************************************************************************
 * Name        : inversioncounter.cpp
 * Author      : Trent Zeller
 * Version     : 1.0
 * Date        : October 29, 2020
 * Description : Counts the number of inversions in an array.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <iostream>
#include <algorithm>
#include <sstream>
#include <vector>
#include <cstdio>
#include <cctype>
#include <cstring>

using namespace std;

// Function prototype.
static long mergesort(int array[], int scratch[], int low, int high);

/**
 * Counts the number of inversions in an array in theta(n^2) time.
 */
long count_inversions_slow(int array[], int length) {
	long count = 0;
    for (long i = 0; i < length; i++){
    	for(long x = i + 1; x < length; x++)
    		if(array[x] < array[i]){
    			count++;
    		}
    }
    return count;
}

/**
 * Counts the number of inversions in an array in theta(n lg n) time.
 */
long count_inversions_fast(int array[], int length) {
	int *scratch = new int[length];
	long rtrn = mergesort(array, scratch, 0, length-1);

	delete[] scratch;
	return rtrn;
}

static long mergesort(int array[], int scratch[], int low, int high) {
	long count = 0;
    if(low < high){
    	int mid = low + (high - low) / 2;
    	count += mergesort(array,scratch,low,mid);
    	count += mergesort(array,scratch,mid+1,high);

    	int l = low, h = mid + 1;
    	for (int k = low; k <= high; k++){
    		if(l <= mid and (h > high || array[l] <= array[h])){
    			scratch[k] = array[l];
    			l = l+1;
    		}
    		else{
    			scratch[k] = array[h];
    			count += mid - l + 1;
    			h = h + 1;
    		}
    	}

    	for(int i = low; i <= high;i ++){
    		array[i] = scratch[i];
    	}
    }
	return count;
}

int main(int argc, char *argv[]) {
    string s;
    istringstream iss;

	if(argc > 2){
    	cerr << "Usage: " << argv[0] << " [slow]";
    	return 1;
    }
	if(argc == 2){
		iss.str(argv[1]);
		if( !(iss >> s)  ){
			cerr << "Usage: " << argv[0] << " [slow].";
			return 1;
		}
		iss.clear();

		if(s != "slow"){
			cerr << "Error: Unrecognized option '" << s << "'.";
			return 1;
		}
	}
    cout << "Enter sequence of integers, each followed by a space: " << flush;

    int value, index = 0;
    vector<int> values;
    string str;
    str.reserve(11);
    char c;
    while (true) {
        c = getchar();
        const bool eoln = c == '\r' || c == '\n';
        if (isspace(c) || eoln) {
            if (str.length() > 0) {
                iss.str(str);
                if (iss >> value) {
                    values.push_back(value);
                } else {
                    cerr << "Error: Non-integer value '" << str
                         << "' received at index " << index << "." << endl;
                    return 1;
                }
                iss.clear();
                ++index;
            }
            if (eoln) {
                break;
            }
            str.clear();
        } else {
            str += c;
        }
    }

    if(values.size() == 0){
    	cerr << "Error: Sequence of integers not received.";
    	return 1;
    }
    if(s == "slow"){
    	cout << "Number of inversions: " << count_inversions_slow(&values[0],values.size());
    }
    else{
    	cout << "Number of inversions: " << count_inversions_fast(&values[0],values.size());
    }

    return 0;
}
